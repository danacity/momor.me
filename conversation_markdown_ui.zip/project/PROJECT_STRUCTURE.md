# Project Structure Overview

## Core Files
- `index.html` - Main HTML entry point
- `vite.config.ts` - Vite configuration
- `tailwind.config.js` - Tailwind CSS configuration
- `postcss.config.js` - PostCSS configuration
- `eslint.config.js` - ESLint configuration
- `vitest.config.ts` - Vitest test configuration

## Source Code Structure

### Entry Points
- `src/main.tsx` - Application entry point
- `src/App.tsx` - Root component
- `src/index.css` - Global styles

### Components
- `src/components/AudioRecorder.tsx` - Handles voice recording functionality
- `src/components/ChatMessage.tsx` - Individual chat message display
- `src/components/ChatToggle.tsx` - Toggle between global and note-specific chats
- `src/components/ChatWindow.tsx` - Main chat interface
- `src/components/Editor.tsx` - Note editor component
- `src/components/FolderItem.tsx` - Folder management in sidebar
- `src/components/NoteItem.tsx` - Individual note display in sidebar
- `src/components/NotePreview.tsx` - Wiki-link preview popup
- `src/components/Preview.tsx` - Note preview with markdown rendering
- `src/components/Sidebar.tsx` - Navigation sidebar

### State Management
- `src/store/chatStore.ts` - Chat state management
- `src/store/noteStore.ts` - Note and folder state management

### Hooks
- `src/hooks/useActiveNote.ts` - Active note management hook

### Utils
- `src/utils/notePath.ts` - Note path and wiki-link processing
- `src/utils/speechToText.ts` - Speech recognition utilities

### Types
- `src/types/index.ts` - TypeScript type definitions

### Tests
- `src/test/setup.ts` - Test environment setup
- `src/components/__tests__/ChatToggle.test.tsx` - Chat toggle tests
- `src/components/__tests__/ChatWindow.test.tsx` - Chat window tests
- `src/components/__tests__/Preview.test.tsx` - Preview component tests
- `src/utils/__tests__/notePath.test.ts` - Note path utility tests

## Configuration Files
- `tsconfig.json` - TypeScript root configuration
- `tsconfig.app.json` - App-specific TypeScript config
- `tsconfig.node.json` - Node-specific TypeScript config