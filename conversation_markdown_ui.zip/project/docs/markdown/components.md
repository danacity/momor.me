# Components Documentation

## AudioRecorder
Audio recording component that handles voice input and transcription.

**Key Features:**
- Voice recording functionality
- Real-time speech-to-text transcription
- Audio playback support
- Recording state management

## ChatMessage
Displays individual chat messages with support for text and audio content.

**Key Features:**
- Expandable message content
- Audio message playback
- Timestamp display
- User/Assistant message styling

## ChatToggle
Toggles between global and note-specific chat contexts.

**Key Features:**
- Context switching between global and note chats
- Visual feedback for active context
- Disabled state for note chat when no note is selected

## ChatWindow
Main chat interface component with message history and input.

**Key Features:**
- Resizable chat window
- Message history display
- Audio recording integration
- Message input handling
- Chat context management

## Editor
Note editing component with real-time updates.

**Key Features:**
- Title editing
- Content editing
- Metadata display
- Auto-save functionality

## FolderItem
Manages folder display and interactions in the sidebar.

**Key Features:**
- Folder expansion/collapse
- Drag and drop support
- Folder renaming
- Note organization

## NoteItem
Displays individual notes in the sidebar.

**Key Features:**
- Note selection
- Drag and drop support
- Note deletion
- Path display

## NotePreview
Popup preview for wiki-style links.

**Key Features:**
- Hover-based preview
- Markdown rendering
- Position adjustment
- Preview content management

## Preview
Main note preview component with wiki-link support.

**Key Features:**
- Markdown rendering
- Wiki-link processing
- Note navigation
- Preview popup integration

## Sidebar
Navigation sidebar with folder and note management.

**Key Features:**
- Folder creation
- Note organization
- Drag and drop support
- Hierarchical display