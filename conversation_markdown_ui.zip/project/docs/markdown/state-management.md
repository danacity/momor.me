# State Management Documentation

## Chat Store
Manages chat-related state using Zustand.

**Key Features:**
- Global and note-specific message storage
- Chat window visibility control
- Chat height management
- Message management functions
- Chat context switching

**State Structure:**
```typescript
{
  messages: {
    global: ChatMessage[];
    notes: Record<string, ChatMessage[]>;
  };
  isOpen: boolean;
  height: number;
  activeChat: 'global' | 'note';
}
```

## Note Store
Manages notes and folders using Zustand.

**Key Features:**
- Note CRUD operations
- Folder management
- Active note tracking
- Note organization
- Folder hierarchy

**State Structure:**
```typescript
{
  notes: Note[];
  folders: Folder[];
  activeNoteId: string | null;
}
```

**Default Data:**
- Default folders: "Questions" and "People"
- Sample notes: "Background" and "Jane Doe"