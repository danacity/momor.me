# Test Documentation

## Markdown Tests

### Basic Formatting
```markdown
# Heading 1
## Heading 2
### Heading 3

**Bold text**
*Italic text*
~~Strikethrough~~

> Blockquote text

1. Ordered list item 1
2. Ordered list item 2

- Unordered list item 1
- Unordered list item 2

`Inline code`

```code
Code block
```

| Header 1 | Header 2 |
|----------|----------|
| Cell 1   | Cell 2   |
```

### Wiki Links
```markdown
Basic link: [[Note Title]]
Link with alias: [[Note Title|Display Text]]
```

### Link Preview Tests
- Hover behavior
- Preview content rendering
- Preview positioning
- Mouse interaction with preview

### Test Results
✅ All markdown elements render correctly
✅ Wiki links work as expected
✅ Link previews function properly