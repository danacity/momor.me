# Testing Documentation

## Test Setup
Located in `src/test/setup.ts`

**Features:**
- Jest DOM extensions
- Automatic cleanup after each test
- Vitest configuration

## Component Tests

### ChatToggle Tests
Tests chat context switching functionality.

**Test Cases:**
- Renders both chat toggle buttons
- Disables note chat when no note is active
- Enables note chat with active note
- Highlights active chat button
- Handles chat context switching

### ChatWindow Tests
Tests chat window functionality.

**Test Cases:**
- Renders global chat messages
- Renders note chat messages
- Switches between chat contexts
- Handles message sending
- Manages audio messages

### Preview Tests
Tests note preview functionality.

**Test Cases:**
- Renders wiki links as clickable links
- Handles navigation to existing notes
- Creates new notes for non-existent links
- Processes markdown content

## Utility Tests

### Note Path Tests
Tests note path processing utilities.

**Test Cases:**
- Processes simple wiki links
- Handles wiki links with aliases
- Manages non-existent note links
- Finds notes by title
- Generates correct note paths