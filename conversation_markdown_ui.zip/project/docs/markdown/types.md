# TypeScript Types Documentation

## Core Types

### Note
Represents a note in the application.

```typescript
interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  folderId: string | null;
}
```

### Folder
Represents a folder in the note hierarchy.

```typescript
interface Folder {
  id: string;
  name: string;
  parentId: string | null;
}
```

### ChatMessage
Represents a message in the chat system.

```typescript
interface ChatMessage {
  id: string;
  content: string;
  timestamp: Date;
  type: 'user' | 'assistant';
  isAudio?: boolean;
  transcription?: string;
}
```

## Store Types

### NoteStore
Note management store interface.

```typescript
interface NoteStore {
  notes: Note[];
  folders: Folder[];
  activeNoteId: string | null;
  setActiveNote: (id: string) => void;
  createNote: (folderId?: string | null, title?: string) => Note;
  updateNote: (id: string, content: string, title?: string) => void;
  deleteNote: (id: string) => void;
  createFolder: (name: string, parentId?: string | null) => void;
  updateFolder: (id: string, name: string) => void;
  deleteFolder: (id: string) => void;
  moveNote: (noteId: string, folderId: string | null) => void;
}
```

### ChatStore
Chat management store interface.

```typescript
interface ChatStore {
  messages: {
    global: ChatMessage[];
    notes: Record<string, ChatMessage[]>;
  };
  isOpen: boolean;
  height: number;
  activeChat: 'global' | 'note';
  addMessage: (content: string, type: 'user' | 'assistant', noteId?: string | null, isAudio?: boolean, transcription?: string) => void;
  toggleChat: () => void;
  setHeight: (height: number) => void;
  setActiveChat: (chatType: 'global' | 'note') => void;
  clearNoteMessages: (noteId: string) => void;
}
```

## Component Props Types

### AudioRecorderProps
Props for the AudioRecorder component.

```typescript
interface AudioRecorderProps {
  onAudioMessage: (audioBlob: Blob, transcription: string) => void;
}
```

### SpeechRecognition
Extended EventTarget interface for speech recognition.

```typescript
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
}
```