# Utilities Documentation

## Note Path Utilities
Located in `src/utils/notePath.ts`

### Functions

#### getNotePath
Generates the full path for a note including its folder hierarchy.

**Usage:**
```typescript
const path = getNotePath(note, folders);
// Example: "People/Jane Doe"
```

#### getDisplayTitle
Extracts the display title from a full path.

**Usage:**
```typescript
const title = getDisplayTitle("People/Jane Doe");
// Returns: "Jane Doe"
```

#### findNoteByPath
Finds a note using its full path.

**Usage:**
```typescript
const note = findNoteByPath("People/Jane Doe", notes, folders);
```

#### findNoteByTitle
Finds a note by its title (case-insensitive).

**Usage:**
```typescript
const note = findNoteByTitle("Jane Doe", notes);
```

#### processWikiLinks
Processes wiki-style links in note content.

**Features:**
- Converts [[Note Title]] to clickable links
- Supports aliases: [[Note Title|Display Text]]
- Creates "new note" links for non-existent notes

## Speech to Text Utilities
Located in `src/utils/speechToText.ts`

### Functions

#### createSpeechRecognition
Creates a speech recognition instance with configured settings.

**Features:**
- Continuous recognition
- Interim results
- English language support
- Browser compatibility check