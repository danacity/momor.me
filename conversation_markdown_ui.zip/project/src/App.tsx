import React from 'react';
import { Sidebar } from './components/Sidebar';
import { Editor } from './components/Editor';
import { Preview } from './components/Preview';
import { ChatWindow } from './components/ChatWindow';
import { useChatStore } from './store/chatStore';
import { useSidebarStore } from './store/sidebarStore';

function App() {
  const { isOpen: isChatOpen, height: chatHeight } = useChatStore();
  const { width: sidebarWidth, isOpen: isSidebarOpen } = useSidebarStore();
  
  return (
    <div className="h-screen bg-gray-900 flex overflow-hidden">
      {/* Sidebar with adjustable width */}
      <div 
        className="flex-none transition-all duration-200 ease-in-out overflow-hidden"
        style={{ width: isSidebarOpen ? `${sidebarWidth}px` : '48px' }}
      >
        <Sidebar />
      </div>

      {/* Main Content Area */}
      <div 
        className="flex-1 flex min-w-0"
        style={{ 
          height: isChatOpen ? `calc(100vh - ${chatHeight}px)` : '100vh'
        }}
      >
        {/* Editor Panel */}
        <div className="w-1/2 min-w-0 overflow-hidden flex flex-col">
          <Editor />
        </div>
        
        {/* Divider */}
        <div className="w-px bg-gray-800" />
        
        {/* Preview Panel */}
        <div className="w-1/2 min-w-0 overflow-hidden flex flex-col">
          <Preview />
        </div>
      </div>

      {/* Chat Window */}
      <ChatWindow />
    </div>
  );
}

export default App;