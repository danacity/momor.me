import React, { useState, useRef } from 'react';
import { Mic, Square, Loader } from 'lucide-react';
import type { AudioRecorderProps, SpeechRecognition } from '../types';
import { createSpeechRecognition } from '../utils/speechToText';

interface ExtendedAudioRecorderProps extends AudioRecorderProps {
  isRecording: boolean;
  setIsRecording: (isRecording: boolean) => void;
  onTranscriptionUpdate: (transcription: string) => void;
}

export const AudioRecorder: React.FC<ExtendedAudioRecorderProps> = ({ 
  onAudioMessage, 
  isRecording, 
  setIsRecording,
  onTranscriptionUpdate
}) => {
  const [isPreparing, setIsPreparing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const transcriptionRef = useRef<string>('');

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];
      transcriptionRef.current = '';

      // Initialize speech recognition
      recognitionRef.current = createSpeechRecognition();
      if (recognitionRef.current) {
        recognitionRef.current.onresult = (event) => {
          const results = Array.from(event.results);
          const transcript = results
            .map(result => result[0].transcript)
            .join(' ');
          transcriptionRef.current = transcript;
          onTranscriptionUpdate(transcript);
        };

        recognitionRef.current.start();
      }

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsPreparing(true);
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        
        // Stop speech recognition
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }

        onAudioMessage(audioBlob, transcriptionRef.current);
        setIsPreparing(false);
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Unable to access microphone. Please ensure you have granted permission.');
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <button
      onClick={isRecording ? stopRecording : startRecording}
      className={`p-2 rounded-full transition-colors ${
        isRecording 
          ? 'bg-red-600 hover:bg-red-700' 
          : isPreparing 
          ? 'bg-gray-700 cursor-wait' 
          : 'bg-gray-700 hover:bg-gray-600'
      }`}
      disabled={isPreparing}
      title={isRecording ? 'Stop recording' : 'Start recording'}
      type="button"
    >
      {isPreparing ? (
        <Loader className="animate-spin" size={16} />
      ) : isRecording ? (
        <Square size={16} className="text-white" />
      ) : (
        <Mic size={16} className="text-white" />
      )}
    </button>
  );
};