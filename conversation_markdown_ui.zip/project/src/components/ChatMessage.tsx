import React, { useRef, useState } from 'react';
import { Mic, ChevronDown, ChevronRight } from 'lucide-react';
import type { ChatMessage as ChatMessageType } from '../types';

interface ChatMessageProps {
  message: ChatMessageType;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
    }
  };

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div
      className={`flex ${
        message.type === 'user' ? 'justify-end' : 'justify-start'
      }`}
    >
      <div
        onClick={toggleExpand}
        className={`max-w-[80%] px-3 py-2 rounded-lg cursor-pointer transition-all ${
          message.type === 'user'
            ? 'bg-blue-600 text-white hover:bg-blue-700'
            : 'bg-gray-800 text-gray-300 hover:bg-gray-750'
        }`}
      >
        <div className="flex items-center gap-2">
          {message.isAudio ? (
            <>
              <Mic size={14} className="shrink-0" />
              <span className="text-sm truncate">
                {isExpanded ? message.transcription : message.transcription.slice(0, 50) + '...'}
              </span>
            </>
          ) : (
            <span className="text-sm">
              {isExpanded ? message.content : message.content.slice(0, 50) + '...'}
            </span>
          )}
          {(message.content.length > 50 || message.isAudio) && (
            <div className="ml-auto pl-2">
              {isExpanded ? (
                <ChevronDown size={14} className="shrink-0" />
              ) : (
                <ChevronRight size={14} className="shrink-0" />
              )}
            </div>
          )}
        </div>

        {isExpanded && (
          <div className="mt-2 space-y-2">
            {message.isAudio && (
              <div className="flex items-center space-x-2 pt-2 border-t border-opacity-20 border-gray-300">
                <button
                  onClick={toggleAudio}
                  className="p-1 hover:bg-opacity-80 rounded text-sm"
                >
                  {isPlaying ? '⏸️' : '▶️'}
                </button>
                <audio
                  ref={audioRef}
                  src={message.content}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                  onEnded={() => setIsPlaying(false)}
                />
                <span className="text-xs opacity-75">Voice message</span>
              </div>
            )}
            <div className="text-xs opacity-75 pt-1">
              {message.timestamp.toLocaleTimeString()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};