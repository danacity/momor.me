import React from 'react';
import { Globe, FileText } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import { useActiveNote } from '../hooks/useActiveNote';

export const ChatToggle: React.FC = () => {
  const { activeChat, setActiveChat } = useChatStore();
  const activeNote = useActiveNote();

  return (
    <div className="flex space-x-2 px-2">
      <button
        onClick={() => setActiveChat('global')}
        className={`flex items-center space-x-2 px-3 py-1 rounded ${
          activeChat === 'global'
            ? 'bg-blue-600 text-white'
            : 'text-gray-400 hover:bg-gray-800'
        }`}
        title="Global Chat"
      >
        <Globe size={14} />
        <span className="text-sm">Global</span>
      </button>
      <button
        onClick={() => setActiveChat('note')}
        disabled={!activeNote}
        className={`flex items-center space-x-2 px-3 py-1 rounded ${
          activeChat === 'note'
            ? 'bg-blue-600 text-white'
            : activeNote
            ? 'text-gray-400 hover:bg-gray-800'
            : 'text-gray-600 cursor-not-allowed'
        }`}
        title={activeNote ? 'Note Chat' : 'Open a note to use note chat'}
      >
        <FileText size={14} />
        <span className="text-sm">Note</span>
      </button>
    </div>
  );
};