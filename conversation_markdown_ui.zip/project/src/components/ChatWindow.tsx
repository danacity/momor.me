import React, { useRef, useEffect, useState } from 'react';
import { Send, ChevronUp, ChevronDown, MessageCircle } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import { useActiveNote } from '../hooks/useActiveNote';
import { AudioRecorder } from './AudioRecorder';
import { ChatMessage } from './ChatMessage';
import { ChatToggle } from './ChatToggle';

export const ChatWindow: React.FC = () => {
  const activeNote = useActiveNote();
  const { messages, isOpen, height, activeChat, addMessage, toggleChat, setHeight } = useChatStore();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isResizing, setIsResizing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);

  const currentMessages = activeChat === 'global' 
    ? messages.global 
    : (activeNote ? messages.notes[activeNote.id] || [] : []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isResizing) {
        const windowHeight = window.innerHeight;
        const minHeight = 150;
        const maxHeight = windowHeight * 0.6;
        const newHeight = Math.min(Math.max(windowHeight - e.clientY, minHeight), maxHeight);
        setHeight(newHeight);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.style.cursor = 'default';
    };

    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'row-resize';
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'default';
    };
  }, [isResizing, setHeight]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      if (audioBlob) {
        const audioUrl = URL.createObjectURL(audioBlob);
        addMessage(audioUrl, 'user', activeChat === 'note' ? activeNote?.id : null, true, input);
        setAudioBlob(null);
      } else {
        addMessage(input, 'user', activeChat === 'note' ? activeNote?.id : null);
      }
      
      setTimeout(() => {
        addMessage('This is a simulated response.', 'assistant', activeChat === 'note' ? activeNote?.id : null);
      }, 1000);
      
      setInput('');
    }
  };

  const handleAudioMessage = (blob: Blob, transcription: string) => {
    setAudioBlob(blob);
    setInput(transcription);
  };

  const handleTranscriptionUpdate = (transcription: string) => {
    setInput(transcription);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0">
      {/* Chat Toggle Bar */}
      <div 
        className="w-full h-6 bg-gray-800 flex items-center justify-center cursor-pointer hover:bg-gray-700 transition-colors"
        onClick={toggleChat}
      >
        <div className="flex items-center gap-2">
          <MessageCircle size={14} className="text-gray-400" />
          <span className="text-sm text-gray-400">
            {activeChat === 'global' ? 'Global Chat' : activeNote?.title ? `Chat: ${activeNote.title}` : 'Note Chat'}
          </span>
          {isOpen ? (
            <ChevronDown className="w-5 h-5 text-gray-400" />
          ) : (
            <ChevronUp className="w-5 h-5 text-gray-400" />
          )}
        </div>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div 
          className="bg-gray-900 flex flex-col"
          style={{ height: `${height}px` }}
        >
          {/* Resize Handle */}
          <div
            className="w-full h-1 cursor-row-resize hover:bg-blue-500 transition-colors"
            onMouseDown={(e) => {
              e.preventDefault();
              setIsResizing(true);
            }}
          />

          {/* Header */}
          <div className="flex-none flex items-center justify-between p-2 border-b border-gray-800">
            <div className="flex items-center space-x-4">
              <span className="font-semibold">Chat</span>
              <ChatToggle />
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {currentMessages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="flex-none p-4 border-t border-gray-800">
            <div className="flex space-x-2">
              <AudioRecorder 
                onAudioMessage={handleAudioMessage}
                isRecording={isRecording}
                setIsRecording={setIsRecording}
                onTranscriptionUpdate={handleTranscriptionUpdate}
              />
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-gray-800 text-gray-100 px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={`Type your message... ${audioBlob ? '(Edit transcription before sending)' : `(${activeChat === 'global' ? 'Global Chat' : 'Note Chat'})`}`}
                disabled={isRecording}
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isRecording}
              >
                <Send size={16} />
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};