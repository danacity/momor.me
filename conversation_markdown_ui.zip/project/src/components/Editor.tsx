import React from 'react';
import { useNoteStore } from '../store/noteStore';
import { useActiveNote } from '../hooks/useActiveNote';

export const Editor: React.FC = () => {
  const { updateNote } = useNoteStore();
  const activeNote = useActiveNote();

  if (!activeNote) return null;

  return (
    <div className="flex-1 h-full flex flex-col">
      <div className="border-b border-gray-800 p-4 bg-gray-900">
        <input
          type="text"
          className="w-full bg-gray-800 text-gray-100 px-3 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={activeNote.title}
          onChange={(e) => updateNote(activeNote.id, activeNote.content, e.target.value)}
          placeholder="Note title..."
        />
        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-400">
          <span>Created: {new Date(activeNote.createdAt).toLocaleDateString()}</span>
          <span>Updated: {new Date(activeNote.updatedAt).toLocaleDateString()}</span>
        </div>
      </div>
      <textarea
        className="flex-1 w-full p-4 bg-gray-900 text-gray-100 resize-none focus:outline-none"
        value={activeNote.content}
        onChange={(e) => updateNote(activeNote.id, e.target.value, activeNote.title)}
        placeholder="Start writing..."
      />
    </div>
  );
};