import React, { useState } from 'react';
import { Plus, ChevronRight, ChevronDown, Folder as FolderIcon } from 'lucide-react';
import { useNoteStore } from '../store/noteStore';
import { NoteItem } from './NoteItem';
import { Folder } from '../types';

interface FolderItemProps {
  folder: Folder;
  level: number;
  expandedFolders: Set<string>;
  onToggleExpand: (folderId: string) => void;
}

export const FolderItem: React.FC<FolderItemProps> = ({
  folder,
  level,
  expandedFolders,
  onToggleExpand,
}) => {
  const { notes, createNote, updateFolder, deleteFolder, moveNote } = useNoteStore();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(folder.name);
  const [isDragOver, setIsDragOver] = useState(false);
  
  const folderNotes = notes.filter((note) => note.folderId === folder.id);
  const isExpanded = expandedFolders.has(folder.id);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      updateFolder(folder.id, name);
      setIsEditing(false);
    }
    if (e.key === 'Escape') {
      setIsEditing(false);
      setName(folder.name);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const noteId = e.dataTransfer.getData('text/plain');
    if (noteId) {
      moveNote(noteId, folder.id);
      if (!isExpanded) {
        onToggleExpand(folder.id);
      }
    }
    setIsDragOver(false);
  };

  return (
    <div>
      <div
        className={`flex items-center px-3 py-2 cursor-pointer transition-colors ${
          isDragOver ? 'bg-blue-500/20' : 'hover:bg-gray-800'
        }`}
        style={{ paddingLeft: `${level * 12 + 12}px` }}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <button
          onClick={() => onToggleExpand(folder.id)}
          className="p-1 hover:bg-gray-700 rounded mr-1"
        >
          {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        </button>
        <FolderIcon size={14} className="mr-2" />
        {isEditing ? (
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={() => {
              updateFolder(folder.id, name);
              setIsEditing(false);
            }}
            className="bg-gray-700 px-2 py-1 rounded flex-1 mr-2"
            autoFocus
          />
        ) : (
          <span
            className="flex-1 truncate"
            onDoubleClick={() => setIsEditing(true)}
          >
            {folder.name}
          </span>
        )}
        <div className="opacity-0 group-hover:opacity-100 flex">
          <button
            onClick={() => createNote(folder.id)}
            className="p-1 hover:bg-gray-700 rounded"
            title="New note"
          >
            <Plus size={14} />
          </button>
          <button
            onClick={() => deleteFolder(folder.id)}
            className="p-1 hover:bg-gray-700 rounded text-red-400"
            title="Delete folder"
          >
            ×
          </button>
        </div>
      </div>
      {isExpanded && (
        <div>
          {folderNotes.map((note) => (
            <NoteItem
              key={note.id}
              note={note}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};