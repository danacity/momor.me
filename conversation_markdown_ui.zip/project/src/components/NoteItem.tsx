import React, { useState } from 'react';
import { FileText, Trash2 } from 'lucide-react';
import { useNoteStore } from '../store/noteStore';
import { getNotePath, getDisplayTitle } from '../utils/notePath';
import type { Note } from '../types';

interface NoteItemProps {
  note: Note;
  level: number;
}

export const NoteItem: React.FC<NoteItemProps> = ({ note, level }) => {
  const { setActiveNote, deleteNote, activeNoteId, folders } = useNoteStore();
  const [isDragging, setIsDragging] = useState(false);
  const isActive = note.id === activeNoteId;

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', note.id);
    e.dataTransfer.effectAllowed = 'move';
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const fullPath = getNotePath(note, folders);
  const displayTitle = getDisplayTitle(fullPath);

  return (
    <div
      className={`flex items-center justify-between p-3 cursor-pointer transition-colors
        ${isActive ? 'bg-gray-800' : 'hover:bg-gray-800'}
        ${isDragging ? 'opacity-50' : ''}
        group`}
      style={{ paddingLeft: `${level * 12 + 12}px` }}
      onClick={() => setActiveNote(note.id)}
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      title={fullPath}
    >
      <div className="flex items-center space-x-2">
        <FileText size={16} />
        <span className="truncate">{displayTitle}</span>
      </div>
      <button
        onClick={(e) => {
          e.stopPropagation();
          deleteNote(note.id);
        }}
        className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-700 rounded transition-opacity"
      >
        <Trash2 size={16} />
      </button>
    </div>
  );
};