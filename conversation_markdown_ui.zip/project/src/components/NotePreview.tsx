import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Note } from '../types';

interface NotePreviewProps {
  note: Note;
  position: { x: number; y: number };
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}

export const NotePreview: React.FC<NotePreviewProps> = ({
  note,
  position,
  onMouseEnter,
  onMouseLeave,
}) => {
  // Adjust position to keep preview within viewport
  const adjustedPosition = {
    x: Math.min(position.x, window.innerWidth - 400),
    y: Math.min(position.y, window.innerHeight - 300),
  };

  return (
    <div
      className="fixed z-50 w-96 max-h-72 bg-gray-900 border border-gray-700 rounded-lg shadow-lg overflow-hidden"
      style={{
        left: adjustedPosition.x,
        top: adjustedPosition.y,
      }}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="p-4 border-b border-gray-800">
        <h2 className="text-lg font-semibold text-gray-100">{note.title}</h2>
      </div>
      <div className="p-4 overflow-y-auto prose prose-invert max-w-none">
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          components={{
            a: ({ href, children }) => (
              <a href={href} className="text-blue-400 hover:text-blue-300">
                {children}
              </a>
            )
          }}
        >
          {note.content}
        </ReactMarkdown>
      </div>
    </div>
  );
};