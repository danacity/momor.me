import React, { useState, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useNoteStore } from '../store/noteStore';
import { useActiveNote } from '../hooks/useActiveNote';
import { getNotePath, processWikiLinks, findNoteByPath, findNoteByTitle } from '../utils/notePath';
import { NotePreview } from './NotePreview';

export const Preview: React.FC = () => {
  const { notes, folders, setActiveNote, createNote, updateNote } = useNoteStore();
  const activeNote = useActiveNote();
  const [previewNote, setPreviewNote] = useState<{
    note: typeof notes[0];
    position: { x: number; y: number };
  } | null>(null);
  const [isHoveringPreview, setIsHoveringPreview] = useState(false);

  const handleLinkHover = useCallback((e: React.MouseEvent<HTMLElement>) => {
    const target = e.target as HTMLElement;
    if (!target.classList.contains('wiki-link')) return;

    const link = target as HTMLAnchorElement;
    const url = new URL(link.href);
    
    if (url.protocol !== 'note:') return;
    
    const path = decodeURIComponent(url.pathname.slice(2));
    const note = findNoteByPath(path, notes, folders) || 
                findNoteByTitle(path.split('/').pop() || '', notes);

    if (note) {
      setPreviewNote({
        note,
        position: {
          x: e.clientX + 20,
          y: e.clientY + 20,
        },
      });
    }
  }, [notes, folders]);

  const handleLinkLeave = useCallback(() => {
    if (!isHoveringPreview) {
      setPreviewNote(null);
    }
  }, [isHoveringPreview]);

  const handlePreviewEnter = useCallback(() => {
    setIsHoveringPreview(true);
  }, []);

  const handlePreviewLeave = useCallback(() => {
    setIsHoveringPreview(false);
    setPreviewNote(null);
  }, []);

  const handleClick = useCallback((e: React.MouseEvent<HTMLElement>) => {
    const target = e.target as HTMLElement;
    if (!target.classList.contains('wiki-link')) return;
    
    e.preventDefault();
    const link = target as HTMLAnchorElement;
    const url = new URL(link.href);
    
    if (url.protocol !== 'note:') return;
    
    const path = decodeURIComponent(url.pathname.slice(2));
    
    if (path.startsWith('create/')) {
      const title = decodeURIComponent(path.slice(7));
      const newNote = createNote(null, title);
      updateNote(newNote.id, `# ${title}\n\n`);
      setActiveNote(newNote.id);
    } else {
      const note = findNoteByPath(path, notes, folders) || 
                  findNoteByTitle(path.split('/').pop() || '', notes);
      if (note) {
        setActiveNote(note.id);
      }
    }
  }, [notes, folders, createNote, updateNote, setActiveNote]);

  if (!activeNote) return null;

  const processedContent = processWikiLinks(activeNote.content, notes, folders);

  return (
    <div className="flex-1 flex flex-col bg-gray-900">
      <div className="border-b border-gray-800 p-4">
        <h1 className="text-2xl font-bold text-gray-100">{getNotePath(activeNote, folders)}</h1>
        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-400">
          <span>Created: {new Date(activeNote.createdAt).toLocaleDateString()}</span>
          <span>Updated: {new Date(activeNote.updatedAt).toLocaleDateString()}</span>
        </div>
      </div>
      <div 
        className="flex-1 p-4 overflow-y-auto prose prose-invert max-w-none"
        onClick={handleClick}
        onMouseMove={handleLinkHover}
        onMouseLeave={handleLinkLeave}
        dangerouslySetInnerHTML={{ __html: processedContent }}
      />
      {previewNote && (
        <NotePreview
          note={previewNote.note}
          position={previewNote.position}
          onMouseEnter={handlePreviewEnter}
          onMouseLeave={handlePreviewLeave}
        />
      )}
    </div>
  );
};