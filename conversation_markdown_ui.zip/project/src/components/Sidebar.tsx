import React, { useState, useRef, useEffect } from 'react';
import { Plus, FolderPlus, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { useNoteStore } from '../store/noteStore';
import { useSidebarStore } from '../store/sidebarStore';
import { useChatStore } from '../store/chatStore';
import { NoteItem } from './NoteItem';
import { FolderItem } from './FolderItem';

export const Sidebar: React.FC = () => {
  const { notes, folders, createNote, createFolder, moveNote } = useNoteStore();
  const { width, setWidth, isOpen, toggleSidebar } = useSidebarStore();
  const { isOpen: isChatOpen, height: chatHeight } = useChatStore();
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['questions']));
  const [newFolderName, setNewFolderName] = useState('');
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const sidebarRef = useRef<HTMLDivElement>(null);

  const filteredNotes = notes.filter((note) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      note.title.toLowerCase().includes(searchLower) ||
      note.content.toLowerCase().includes(searchLower)
    );
  });

  const rootNotes = filteredNotes.filter((note) => note.folderId === null);
  const rootFolders = folders.filter((folder) => folder.parentId === null);

  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!sidebarRef.current) return;
      const minWidth = 200;
      const maxWidth = Math.min(600, window.innerWidth * 0.4);
      const newWidth = Math.max(minWidth, Math.min(e.clientX, maxWidth));
      setWidth(newWidth);
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.style.cursor = 'default';
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.body.style.cursor = 'col-resize';

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'default';
    };
  }, [isResizing, setWidth]);

  return (
    <div 
      ref={sidebarRef}
      className="h-full flex relative"
    >
      {/* Sidebar Controls */}
      <div className="flex-none w-12 flex flex-col bg-gray-900 text-gray-300 border-r border-gray-800">
        <div className="p-2">
          <div className="flex flex-col space-y-2">
            <button
              onClick={() => createNote()}
              className="p-2 hover:bg-gray-800 rounded flex items-center justify-center"
              title="New note"
            >
              <Plus size={20} />
            </button>
            <button
              onClick={() => setIsCreatingFolder(true)}
              className="p-2 hover:bg-gray-800 rounded flex items-center justify-center"
              title="New folder"
            >
              <FolderPlus size={20} />
            </button>
            <button
              onClick={toggleSidebar}
              className="p-2 hover:bg-gray-800 rounded flex items-center justify-center"
              title={isOpen ? "Collapse sidebar" : "Expand sidebar"}
            >
              {isOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Sidebar Content */}
      {isOpen && (
        <div className="flex-1 flex flex-col bg-gray-900 text-gray-300 min-w-0 overflow-hidden">
          {/* Search Bar */}
          <div className="p-4 border-b border-gray-800">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search notes..."
                className="w-full bg-gray-800 px-3 py-2 pl-10 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>

          {/* Notes and Folders List */}
          <div 
            className="flex-1 overflow-y-auto"
            style={{ 
              height: isChatOpen ? `calc(100vh - ${chatHeight + 64}px)` : 'calc(100vh - 64px)'
            }}
          >
            {isCreatingFolder && (
              <div className="px-4 py-2">
                <input
                  type="text"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newFolderName.trim()) {
                      createFolder(newFolderName);
                      setNewFolderName('');
                      setIsCreatingFolder(false);
                    }
                    if (e.key === 'Escape') {
                      setIsCreatingFolder(false);
                      setNewFolderName('');
                    }
                  }}
                  placeholder="Folder name..."
                  className="w-full bg-gray-800 px-2 py-1 rounded"
                  autoFocus
                />
              </div>
            )}
            {rootFolders.map((folder) => (
              <FolderItem
                key={folder.id}
                folder={folder}
                level={0}
                expandedFolders={expandedFolders}
                onToggleExpand={(folderId) => {
                  setExpandedFolders((prev) => {
                    const next = new Set(prev);
                    if (next.has(folderId)) {
                      next.delete(folderId);
                    } else {
                      next.add(folderId);
                    }
                    return next;
                  });
                }}
              />
            ))}
            {rootNotes.map((note) => (
              <NoteItem
                key={note.id}
                note={note}
                level={0}
              />
            ))}
            
            {/* Spacer to prevent content from being hidden under chat */}
            {isChatOpen && <div style={{ height: `${chatHeight}px` }} />}
          </div>
        </div>
      )}

      {/* Resize Handle */}
      {isOpen && (
        <div
          className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 transition-colors"
          onMouseDown={(e) => {
            e.preventDefault();
            setIsResizing(true);
          }}
        />
      )}
    </div>
  );
};