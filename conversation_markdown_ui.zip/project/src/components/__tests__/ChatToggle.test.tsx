import { describe, test, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ChatToggle } from '../ChatToggle';
import { useChatStore } from '../../store/chatStore';
import { useActiveNote } from '../../hooks/useActiveNote';

vi.mock('../../store/chatStore');
vi.mock('../../hooks/useActiveNote');

describe('ChatToggle Component', () => {
  const mockSetActiveChat = vi.fn();

  beforeEach(() => {
    vi.mocked(useChatStore).mockReturnValue({
      activeChat: 'global',
      setActiveChat: mockSetActiveChat
    } as any);
  });

  test('renders both chat toggle buttons', () => {
    render(<ChatToggle />);
    
    expect(screen.getByText('Global')).toBeInTheDocument();
    expect(screen.getByText('Note')).toBeInTheDocument();
  });

  test('disables note chat button when no note is active', () => {
    vi.mocked(useActiveNote).mockReturnValue(null);
    render(<ChatToggle />);
    
    const noteButton = screen.getByTitle('Open a note to use note chat');
    expect(noteButton).toBeDisabled();
  });

  test('enables note chat button when a note is active', () => {
    vi.mocked(useActiveNote).mockReturnValue({
      id: 'note-1',
      title: 'Test Note',
      content: '',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: null
    });

    render(<ChatToggle />);
    
    const noteButton = screen.getByTitle('Note Chat');
    expect(noteButton).not.toBeDisabled();
  });

  test('highlights active chat button', () => {
    render(<ChatToggle />);
    
    const globalButton = screen.getByText('Global').parentElement;
    expect(globalButton).toHaveClass('bg-blue-600');

    vi.mocked(useChatStore).mockReturnValue({
      activeChat: 'note',
      setActiveChat: mockSetActiveChat
    } as any);

    render(<ChatToggle />);
    
    const noteButton = screen.getByText('Note').parentElement;
    expect(noteButton).toHaveClass('bg-blue-600');
  });

  test('calls setActiveChat when buttons are clicked', () => {
    vi.mocked(useActiveNote).mockReturnValue({
      id: 'note-1',
      title: 'Test Note',
      content: '',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: null
    });

    render(<ChatToggle />);
    
    const globalButton = screen.getByText('Global').parentElement!;
    const noteButton = screen.getByText('Note').parentElement!;

    fireEvent.click(globalButton);
    expect(mockSetActiveChat).toHaveBeenCalledWith('global');

    fireEvent.click(noteButton);
    expect(mockSetActiveChat).toHaveBeenCalledWith('note');
  });
});