import { describe, test, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ChatWindow } from '../ChatWindow';
import { useChatStore } from '../../store/chatStore';
import { useActiveNote } from '../../hooks/useActiveNote';

// Mock the stores and hooks
vi.mock('../../store/chatStore');
vi.mock('../../hooks/useActiveNote');

describe('ChatWindow Component', () => {
  const mockSetActiveChat = vi.fn();
  const mockAddMessage = vi.fn();
  const mockToggleChat = vi.fn();

  const mockGlobalMessages = [
    {
      id: '1',
      content: 'Global message 1',
      timestamp: new Date('2024-03-10T10:00:00'),
      type: 'user'
    },
    {
      id: '2',
      content: 'Global response 1',
      timestamp: new Date('2024-03-10T10:01:00'),
      type: 'assistant'
    }
  ];

  const mockNoteMessages = [
    {
      id: '3',
      content: 'Note message 1',
      timestamp: new Date('2024-03-10T11:00:00'),
      type: 'user'
    },
    {
      id: '4',
      content: 'Note response 1',
      timestamp: new Date('2024-03-10T11:01:00'),
      type: 'assistant'
    }
  ];

  const mockNote = {
    id: 'note-1',
    title: 'Test Note',
    content: 'Test content',
    createdAt: new Date(),
    updatedAt: new Date(),
    folderId: null
  };

  beforeEach(() => {
    vi.mocked(useChatStore).mockReturnValue({
      messages: {
        global: mockGlobalMessages,
        notes: {
          'note-1': mockNoteMessages
        }
      },
      isOpen: true,
      height: 300,
      activeChat: 'global',
      addMessage: mockAddMessage,
      toggleChat: mockToggleChat,
      setActiveChat: mockSetActiveChat,
      setHeight: vi.fn(),
      clearNoteMessages: vi.fn()
    } as any);

    vi.mocked(useActiveNote).mockReturnValue(mockNote);
  });

  test('renders global chat messages when global chat is active', () => {
    render(<ChatWindow />);
    
    expect(screen.getByText('Global message 1')).toBeInTheDocument();
    expect(screen.getByText('Global response 1')).toBeInTheDocument();
    expect(screen.queryByText('Note message 1')).not.toBeInTheDocument();
  });

  test('renders note chat messages when note chat is active', () => {
    vi.mocked(useChatStore).mockReturnValue({
      ...useChatStore(),
      activeChat: 'note'
    } as any);

    render(<ChatWindow />);
    
    expect(screen.getByText('Note message 1')).toBeInTheDocument();
    expect(screen.getByText('Note response 1')).toBeInTheDocument();
    expect(screen.queryByText('Global message 1')).not.toBeInTheDocument();
  });

  test('switches between global and note chat', () => {
    render(<ChatWindow />);
    
    const noteButton = screen.getByTitle('Note Chat');
    fireEvent.click(noteButton);
    
    expect(mockSetActiveChat).toHaveBeenCalledWith('note');
  });

  test('sends message to correct chat context', () => {
    render(<ChatWindow />);
    
    const input = screen.getByPlaceholderText(/Type your message/i);
    fireEvent.change(input, { target: { value: 'Test message' } });
    
    const sendButton = screen.getByRole('button', { name: '' }); // Send button has no text, only icon
    fireEvent.click(sendButton);
    
    expect(mockAddMessage).toHaveBeenCalledWith('Test message', 'user', null);

    // Switch to note chat and send message
    vi.mocked(useChatStore).mockReturnValue({
      ...useChatStore(),
      activeChat: 'note'
    } as any);

    render(<ChatWindow />);
    
    fireEvent.change(input, { target: { value: 'Note message' } });
    fireEvent.click(sendButton);
    
    expect(mockAddMessage).toHaveBeenCalledWith('Note message', 'user', 'note-1');
  });
});