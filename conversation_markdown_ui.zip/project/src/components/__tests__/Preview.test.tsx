import { describe, test, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Preview } from '../Preview';
import { useNoteStore } from '../../store/noteStore';
import { useActiveNote } from '../../hooks/useActiveNote';
import { writeTestResults } from '../../test/setup';

vi.mock('../../store/noteStore');
vi.mock('../../hooks/useActiveNote');

describe('Preview Component', () => {
  const mockNotes = [
    {
      id: 'test-note',
      title: 'Test Note',
      content: '# Test Note\nThis is a test note with a [[Linked Note]] in it.\n\n**Bold text**\n*Italic text*\n\n- List item 1\n- List item 2',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: null
    },
    {
      id: 'linked-note',
      title: 'Linked Note',
      content: '# Linked Note\nThis is the linked note content.',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: null
    }
  ];

  beforeEach(() => {
    vi.mocked(useActiveNote).mockReturnValue(mockNotes[0]);
    vi.mocked(useNoteStore).mockReturnValue({
      notes: mockNotes,
      folders: [],
      setActiveNote: vi.fn(),
      createNote: vi.fn(),
      updateNote: vi.fn()
    } as any);
  });

  describe('Markdown Rendering', () => {
    test('renders markdown elements correctly', () => {
      const { container } = render(<Preview />);
      
      const result = {
        passed: true,
        elements: {
          heading: Boolean(container.querySelector('h1')),
          bold: Boolean(container.querySelector('strong')),
          italic: Boolean(container.querySelector('em')),
          list: Boolean(container.querySelector('ul')),
        }
      };
      
      writeTestResults('markdown-rendering', result);
      
      // Verify headings
      expect(container.querySelector('h1')).toHaveTextContent('Test Note');
      
      // Verify bold and italic
      expect(container.querySelector('strong')).toHaveTextContent('Bold text');
      expect(container.querySelector('em')).toHaveTextContent('Italic text');
      
      // Verify lists
      const listItems = container.querySelectorAll('li');
      expect(listItems).toHaveLength(2);
      expect(listItems[0]).toHaveTextContent('List item 1');
      expect(listItems[1]).toHaveTextContent('List item 2');
    });
  });

  describe('Wiki Link Preview', () => {
    test('shows preview when hovering over wiki link', async () => {
      const { container } = render(<Preview />);
      
      // Find wiki link
      const wikiLink = container.querySelector('a.wiki-link');
      expect(wikiLink).toBeInTheDocument();
      
      // Trigger hover
      fireEvent.mouseMove(wikiLink!);
      
      // Verify preview appears
      await waitFor(() => {
        const preview = screen.getByText('This is the linked note content.');
        expect(preview).toBeInTheDocument();
      });
      
      const result = {
        passed: true,
        events: {
          linkFound: Boolean(wikiLink),
          previewShown: Boolean(screen.queryByText('This is the linked note content.'))
        }
      };
      
      writeTestResults('wiki-link-preview', result);
    });

    test('maintains preview while mouse is over link or preview', async () => {
      const { container } = render(<Preview />);
      
      // Find and hover over link
      const wikiLink = container.querySelector('a.wiki-link')!;
      fireEvent.mouseMove(wikiLink);
      
      // Wait for preview
      const preview = await screen.findByText('This is the linked note content.');
      
      // Move to preview
      fireEvent.mouseEnter(preview.parentElement!);
      expect(preview).toBeInTheDocument();
      
      // Move back to link
      fireEvent.mouseEnter(wikiLink);
      expect(preview).toBeInTheDocument();
      
      const result = {
        passed: true,
        events: {
          previewMaintained: Boolean(screen.queryByText('This is the linked note content.'))
        }
      };
      
      writeTestResults('wiki-link-preview-hover', result);
    });

    test('hides preview when mouse leaves both elements', async () => {
      const { container } = render(<Preview />);
      
      // Find and hover over link
      const wikiLink = container.querySelector('a.wiki-link')!;
      fireEvent.mouseMove(wikiLink);
      
      // Wait for preview
      const preview = await screen.findByText('This is the linked note content.');
      
      // Leave both elements
      fireEvent.mouseLeave(wikiLink);
      fireEvent.mouseLeave(preview.parentElement!);
      
      // Verify preview disappears
      await waitFor(() => {
        expect(screen.queryByText('This is the linked note content.')).not.toBeInTheDocument();
      });
      
      const result = {
        passed: true,
        events: {
          previewHidden: !screen.queryByText('This is the linked note content.')
        }
      };
      
      writeTestResults('wiki-link-preview-hide', result);
    });
  });
});