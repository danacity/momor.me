import { useNoteStore } from '../store/noteStore';

export const useActiveNote = () => {
  const { notes, activeNoteId } = useNoteStore();
  const activeNote = notes.find((note) => note.id === activeNoteId);
  return activeNote;
};