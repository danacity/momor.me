import { create } from 'zustand';
import { ChatStore, ChatMessage } from '../types';

const createChatStore = () => {
  const store = create<ChatStore>((set) => ({
    messages: {
      global: [],
      notes: {},
    },
    isOpen: true,
    height: 300,
    activeChat: 'global',

    addMessage: (content, type, noteId = null, isAudio = false, transcription = '') =>
      set((state) => {
        const newMessage: ChatMessage = {
          id: Date.now().toString(),
          content,
          timestamp: new Date(),
          type,
          isAudio,
          transcription,
        };

        if (noteId) {
          return {
            messages: {
              ...state.messages,
              notes: {
                ...state.messages.notes,
                [noteId]: [...(state.messages.notes[noteId] || []), newMessage],
              },
            },
          };
        }

        return {
          messages: {
            ...state.messages,
            global: [...state.messages.global, newMessage],
          },
        };
      }),

    toggleChat: () =>
      set((state) => ({
        isOpen: !state.isOpen,
        height: state.height || 300, // Restore previous height when reopening
      })),

    setHeight: (height) =>
      set({
        height,
      }),

    setActiveChat: (chatType) =>
      set({
        activeChat: chatType,
      }),

    clearNoteMessages: (noteId) =>
      set((state) => {
        const { [noteId]: _, ...restNotes } = state.messages.notes;
        return {
          messages: {
            ...state.messages,
            notes: restNotes,
          },
        };
      }),
  }));

  return store;
};

export const useChatStore = createChatStore();