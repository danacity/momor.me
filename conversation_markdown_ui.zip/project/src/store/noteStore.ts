import { create } from 'zustand';
import { Note, NoteStore, Folder } from '../types';
import { getNotePath } from '../utils/notePath';
import { readMarkdownFiles } from '../utils/markdownReader';

const defaultFolders: Folder[] = [
  {
    id: 'questions',
    name: 'Questions',
    parentId: null,
  },
  {
    id: 'people',
    name: 'People',
    parentId: null,
  },
  {
    id: 'docs',
    name: 'Documentation',
    parentId: null,
  }
];

const defaultNotes: Note[] = [
  {
    id: 'background',
    title: 'Background',
    content: '# Background\n\nMy name is [[Jane Doe]]',
    createdAt: new Date(),
    updatedAt: new Date(),
    folderId: 'questions',
  },
  {
    id: 'jane-doe',
    title: 'Jane Doe',
    content: '# Jane Doe\n\nThis is Jane Doe\'s profile.',
    createdAt: new Date(),
    updatedAt: new Date(),
    folderId: 'people',
  }
];

export const useNoteStore = create<NoteStore>((set, get) => {
  // Load markdown files immediately
  readMarkdownFiles().then(markdownNotes => {
    set({ notes: [...defaultNotes, ...markdownNotes] });
  });

  return {
    notes: defaultNotes,
    folders: defaultFolders,
    activeNoteId: 'background',
    
    setActiveNote: (id) => set({ activeNoteId: id }),
    
    createNote: (folderId = null, title?: string) => {
      const { notes, folders } = get();
      const defaultTitle = title || 'Untitled';
      let counter = 1;
      let newTitle = defaultTitle;
      
      while (notes.some(note => getNotePath(note, folders) === newTitle)) {
        newTitle = `${defaultTitle}_${counter}`;
        counter++;
      }

      const newNote: Note = {
        id: Date.now().toString(),
        title: newTitle,
        content: `# ${newTitle}\n\n`,
        createdAt: new Date(),
        updatedAt: new Date(),
        folderId,
      };

      set((state) => ({
        notes: [...state.notes, newNote],
        activeNoteId: newNote.id,
      }));

      return newNote;
    },

    updateNote: (id, content, title) => {
      set((state) => ({
        notes: state.notes.map((note) =>
          note.id === id
            ? {
                ...note,
                content,
                title: title || note.title,
                updatedAt: new Date(),
              }
            : note
        ),
      }));
    },

    deleteNote: (id) => {
      set((state) => ({
        notes: state.notes.filter((note) => note.id !== id),
        activeNoteId:
          state.activeNoteId === id
            ? state.notes[0]?.id || null
            : state.activeNoteId,
      }));
    },

    createFolder: (name, parentId = null) => {
      const newFolder: Folder = {
        id: Date.now().toString(),
        name,
        parentId,
      };

      set((state) => ({
        folders: [...state.folders, newFolder],
      }));
    },

    updateFolder: (id, name) => {
      set((state) => ({
        folders: state.folders.map((folder) =>
          folder.id === id ? { ...folder, name } : folder
        ),
      }));
    },

    deleteFolder: (id) => {
      set((state) => {
        const folderIds = new Set([id]);
        const getChildFolders = (parentId: string) => {
          state.folders.forEach((folder) => {
            if (folder.parentId === parentId) {
              folderIds.add(folder.id);
              getChildFolders(folder.id);
            }
          });
        };
        getChildFolders(id);

        return {
          folders: state.folders.filter((folder) => !folderIds.has(folder.id)),
          notes: state.notes.map((note) =>
            folderIds.has(note.folderId || '')
              ? { ...note, folderId: null }
              : note
          ),
        };
      });
    },

    moveNote: (noteId, folderId) => {
      set((state) => ({
        notes: state.notes.map((note) =>
          note.id === noteId ? { ...note, folderId } : note
        ),
      }));
    },
  };
});