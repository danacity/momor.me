import { create } from 'zustand';

interface SidebarStore {
  isOpen: boolean;
  width: number;
  toggleSidebar: () => void;
  setWidth: (width: number) => void;
}

export const useSidebarStore = create<SidebarStore>((set) => ({
  isOpen: true,
  width: 256,
  toggleSidebar: () => set((state) => ({ isOpen: !state.isOpen })),
  setWidth: (width) => set({ width }),
}));