import '@testing-library/jest-dom';
import { expect, afterEach, beforeAll } from 'vitest';
import { cleanup } from '@testing-library/react';
import fs from 'fs';

// Custom test reporter
beforeAll(() => {
  const originalConsoleError = console.error;
  console.error = (...args) => {
    // Filter out React internal errors during tests
    if (typeof args[0] === 'string' && args[0].includes('Warning:')) {
      return;
    }
    originalConsoleError.apply(console, args);
  };
});

// Enhanced error reporting
expect.extend({
  toHaveRenderedProperly(received: any, expected: any) {
    const pass = this.equals(received, expected);
    if (pass) {
      return {
        message: () =>
          `Expected element not to be rendered properly, but it was:\n${this.utils.printReceived(received)}`,
        pass: true,
      };
    } else {
      return {
        message: () =>
          `Expected element to be rendered properly:\n` +
          `Expected: ${this.utils.printExpected(expected)}\n` +
          `Received: ${this.utils.printReceived(received)}\n` +
          `Difference: ${this.utils.diff(expected, received)}`,
        pass: false,
      };
    }
  },
});

// Cleanup after each test
afterEach(() => {
  cleanup();
});

// Create test results directory if it doesn't exist
const testResultsDir = 'test-results';
if (!fs.existsSync(testResultsDir)) {
  fs.mkdirSync(testResultsDir);
}

// Write test results to file
export const writeTestResults = (testName: string, results: any) => {
  const filePath = `${testResultsDir}/${testName}.json`;
  fs.writeFileSync(filePath, JSON.stringify(results, null, 2));

  // Write to summary file
  const summaryPath = `${testResultsDir}/summary.json`;
  const summary = fs.existsSync(summaryPath) 
    ? JSON.parse(fs.readFileSync(summaryPath, 'utf-8'))
    : {};

  summary[testName] = {
    ...results,
    timestamp: new Date().toISOString()
  };

  fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2));

  // If test failed, log detailed information
  if (!results.passed) {
    console.log(`\nTest failed: ${testName}`);
    console.log('Input:', results.input);
    console.log('Expected:', results.expected);
    console.log('Received:', results.received);
    console.log('Difference:', results.difference || '');
    console.log('-------------------');
  }
};