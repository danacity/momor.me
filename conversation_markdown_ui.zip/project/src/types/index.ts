import { ReactNode } from 'react';

export interface Folder {
  id: string;
  name: string;
  parentId: string | null;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  folderId: string | null;
}

export interface NoteStore {
  notes: Note[];
  folders: Folder[];
  activeNoteId: string | null;
  setActiveNote: (id: string) => void;
  createNote: (folderId?: string | null, title?: string) => Note;
  updateNote: (id: string, content: string, title?: string) => void;
  deleteNote: (id: string) => void;
  createFolder: (name: string, parentId?: string | null) => void;
  updateFolder: (id: string, name: string) => void;
  deleteFolder: (id: string) => void;
  moveNote: (noteId: string, folderId: string | null) => void;
}

export interface ChatMessage {
  id: string;
  content: string;
  timestamp: Date;
  type: 'user' | 'assistant';
  isAudio?: boolean;
  transcription?: string;
}

export interface ChatStore {
  messages: {
    global: ChatMessage[];
    notes: Record<string, ChatMessage[]>;
  };
  isOpen: boolean;
  height: number;
  activeChat: 'global' | 'note';
  addMessage: (content: string, type: 'user' | 'assistant', noteId?: string | null, isAudio?: boolean, transcription?: string) => void;
  toggleChat: () => void;
  setHeight: (height: number) => void;
  setActiveChat: (chatType: 'global' | 'note') => void;
  clearNoteMessages: (noteId: string) => void;
}

export interface AudioRecorderProps {
  onAudioMessage: (audioBlob: Blob, transcription: string) => void;
}

export interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: (event: any) => void;
  onerror: (event: any) => void;
  onend: () => void;
}