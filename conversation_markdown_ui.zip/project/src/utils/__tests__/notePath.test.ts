import { describe, test, expect } from 'vitest';
import { processWikiLinks, findNoteByTitle, getNotePath } from '../notePath';
import type { Note, Folder } from '../../types';
import { writeTestResults } from '../../test/setup';

describe('Wiki Links Processing', () => {
  const folders: Folder[] = [
    { id: 'people', name: 'People', parentId: null },
    { id: 'questions', name: 'Questions', parentId: null },
    { id: 'nested', name: 'Nested', parentId: 'people' }
  ];

  const notes: Note[] = [
    {
      id: 'jane-doe',
      title: 'Jane Doe',
      content: '# Jane Doe\nThis is Jane Doe\'s profile.',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: 'people'
    },
    {
      id: 'background',
      title: 'Background',
      content: '# Background\nMy name is [[Jane Doe]]',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: 'questions'
    },
    {
      id: 'special-chars',
      title: 'Special & Chars',
      content: '# Special & Chars\nTest note with special characters',
      createdAt: new Date(),
      updatedAt: new Date(),
      folderId: 'nested'
    }
  ];

  test('processes simple wiki links correctly', () => {
    const input = 'My name is [[Jane Doe]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = 'My name is <a href="note://People/Jane%20Doe" class="wiki-link">Jane Doe</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Link format mismatch'
    };
    
    writeTestResults('wiki-links-simple', result);
    expect(processed).toBe(expected);
  });

  test('processes wiki links with aliases', () => {
    const input = 'Written by [[Jane Doe|Jane]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = 'Written by <a href="note://People/Jane%20Doe" class="wiki-link">Jane</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Link format mismatch'
    };
    
    writeTestResults('wiki-links-aliases', result);
    expect(processed).toBe(expected);
  });

  test('handles non-existent notes with create links', () => {
    const input = '[[New Note]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = '<a href="note://create/New%20Note" class="wiki-link new-note">New Note</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Create link format mismatch'
    };
    
    writeTestResults('wiki-links-create', result);
    expect(processed).toBe(expected);
  });

  test('preserves surrounding text', () => {
    const input = 'Before [[Jane Doe]] After';
    const processed = processWikiLinks(input, notes, folders);
    const expected = 'Before <a href="note://People/Jane%20Doe" class="wiki-link">Jane Doe</a> After';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Text preservation mismatch'
    };
    
    writeTestResults('wiki-links-context', result);
    expect(processed).toBe(expected);
  });

  test('handles special characters in note titles', () => {
    const input = '[[Special & Chars]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = '<a href="note://People/Nested/Special%20%26%20Chars" class="wiki-link">Special & Chars</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Special characters handling mismatch'
    };
    
    writeTestResults('wiki-links-special-chars', result);
    expect(processed).toBe(expected);
  });

  test('handles multiple wiki links in the same text', () => {
    const input = '[[Jane Doe]] works with [[Special & Chars]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = '<a href="note://People/Jane%20Doe" class="wiki-link">Jane Doe</a> works with <a href="note://People/Nested/Special%20%26%20Chars" class="wiki-link">Special & Chars</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Multiple links handling mismatch'
    };
    
    writeTestResults('wiki-links-multiple', result);
    expect(processed).toBe(expected);
  });

  test('handles empty wiki links', () => {
    const input = '[[]]';
    const processed = processWikiLinks(input, notes, folders);
    const expected = '<a href="note://create/Untitled" class="wiki-link new-note">Untitled</a>';
    
    const result = {
      passed: processed === expected,
      input,
      expected,
      received: processed,
      difference: processed === expected ? null : 'Empty link handling mismatch'
    };
    
    writeTestResults('wiki-links-empty', result);
    expect(processed).toBe(expected);
  });
});