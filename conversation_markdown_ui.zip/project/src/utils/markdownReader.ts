import type { Note } from '../types';

export async function readMarkdownFiles(): Promise<Note[]> {
  const notes: Note[] = [];
  const markdownFiles = import.meta.glob('/docs/markdown/*.md', { 
    eager: true, 
    as: 'raw' 
  });

  for (const [path, content] of Object.entries(markdownFiles)) {
    try {
      const id = path.split('/').pop()?.replace('.md', '') ?? '';
      const title = (content as string).split('\n')[0].replace('# ', '');
      
      notes.push({
        id,
        title,
        content: content as string,
        createdAt: new Date(),
        updatedAt: new Date(),
        folderId: 'docs'
      });
    } catch (error) {
      console.error(`Error reading markdown file ${path}:`, error);
    }
  }

  return notes;
}