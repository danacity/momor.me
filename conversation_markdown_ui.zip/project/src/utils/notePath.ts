import { Note, Folder } from '../types';

export const getNotePath = (note: Note, folders: Folder[]): string => {
  if (!note.folderId) return note.title;

  const getFolderPath = (folderId: string): string[] => {
    const folder = folders.find(f => f.id === folderId);
    if (!folder) return [];
    if (!folder.parentId) return [folder.name];
    return [...getFolderPath(folder.parentId), folder.name];
  };

  const folderPath = note.folderId ? getFolderPath(note.folderId) : [];
  return [...folderPath, note.title].join('/');
};

export const getDisplayTitle = (path: string): string => {
  return path.split('/').pop() || path;
};

export const findNoteByPath = (path: string, notes: Note[], folders: Folder[]): Note | undefined => {
  return notes.find(note => getNotePath(note, folders) === path);
};

export const findNoteByTitle = (title: string, notes: Note[]): Note | undefined => {
  const normalizedTitle = title.trim().toLowerCase();
  return notes.find(note => note.title.toLowerCase() === normalizedTitle);
};

export const processWikiLinks = (content: string, notes: Note[], folders: Folder[]): string => {
  const wikiLinkRegex = /\[\[(.*?)(?:\|(.*?))?\]\]/g;
  
  return content.replace(wikiLinkRegex, (match, noteName, alias) => {
    const title = noteName.trim();
    const displayText = alias?.trim() || title;
    const note = findNoteByTitle(title, notes);
    
    if (note) {
      const notePath = getNotePath(note, folders);
      // Use encodeURIComponent only on the individual parts, not the whole path
      const encodedPath = notePath.split('/').map(part => encodeURIComponent(part)).join('/');
      return `<a href="note://${encodedPath}" class="wiki-link">${displayText}</a>`;
    }
    
    return `<a href="note://create/${encodeURIComponent(title)}" class="wiki-link new-note">${displayText}</a>`;
  });
};