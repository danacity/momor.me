import { SpeechRecognition } from '../types';

export const createSpeechRecognition = (): SpeechRecognition | null => {
  if (!('webkitSpeechRecognition' in window)) {
    console.warn('Speech recognition is not supported in this browser');
    return null;
  }

  // @ts-ignore: Webkit prefix
  const recognition = new webkitSpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  return recognition;
};